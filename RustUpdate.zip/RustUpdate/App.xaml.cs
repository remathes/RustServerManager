using System.Windows;

namespace RustUpdate
{
    public partial class App : Application
    {
        
    }
}
